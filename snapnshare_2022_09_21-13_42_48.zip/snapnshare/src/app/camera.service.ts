import { Injectable } from "@angular/core";

@Injectable()
export class CameraService {

  dataUrl: string = ""

}
